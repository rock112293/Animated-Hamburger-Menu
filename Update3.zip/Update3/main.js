//function to hamburger Menu
function toggle(){
  var div = document.getElementById('div');
  div.classList.toggle('active');
}
//Update 3 for circle feature.